/**
 * ABOUT.js, Kopano Webapp contact to vcf im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.contactimporter');

/**
 * @class Zarafa.plugins.contactimporter.ABOUT
 * @extends String
 *
 * The copyright string holding the copyright notice for the Zarafa contactimporter Plugin.
 */
Zarafa.plugins.contactimporter.ABOUT = ""
    + "<p>Copyright (C) 2012-2018  Christoph Haas &lt;christoph.h@sprinternet.at&gt;</p>"

    + "<p>This program is free software; you can redistribute it and/or "
    + "modify it under the terms of the GNU Lesser General Public "
    + "License as published by the Free Software Foundation; either "
    + "version 2.1 of the License, or (at your option) any later version.</p>"

    + "<p>This program is distributed in the hope that it will be useful, "
    + "but WITHOUT ANY WARRANTY; without even the implied warranty of "
    + "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU "
    + "Lesser General Public License for more details.</p>"

    + "<p>You should have received a copy of the GNU Lesser General Public "
    + "License along with this program; if not, write to the Free Software "
    + "Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA</p>"

    + "<hr />"

    + "<p>The contactimporter plugin contains the following third-party components:</p>"

    + "<h1>vCard-parser</h1>"

    + "<p>Copyright (C) 2016 Jeroen Desloovere</p>"

    + "<p>Licensed under the MIT License.</p>"

    + "<p>Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.</p>"/**
 * Actions.js, Kopano Webapp contact to vcf im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.contactimporter.data');

/**
 * @class Zarafa.plugins.contactimporter.data.Actions
 * Common actions which can be used within {@link Ext.Button buttons}
 * or other {@link Ext.Component components} with action handlers.
 * @singleton
 */
Zarafa.plugins.contactimporter.data.Actions = {
    /**
     * Generates a request to download the selected records as vCard.
     *
     * @param storeId
     * @param recordIds
     */
    exportToVCF: function (storeId, recordIds, recordFolder) {
        if ((typeof recordIds != "undefined" && recordIds.length < 1) || (typeof recordFolder != "undefined" && recordFolder.get('content_count') < 1)) {
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_contactimporter', 'Error'),
                msg: dgettext('plugin_contactimporter', 'No contacts found. Export skipped!'),
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        } else {

            var responseHandler = new Zarafa.plugins.contactimporter.data.ResponseHandler({
                successCallback: Zarafa.plugins.contactimporter.data.Actions.downloadVCF
            });

            var recordcount = 0;
            var exportPayload = {
                storeid: storeId,
                records: undefined,
                folder: undefined
            };

            if (typeof recordIds != "undefined") {
                exportPayload.records = recordIds;
                recordcount = recordIds.length;
            }

            if (typeof recordFolder != "undefined") {
                exportPayload.folder = recordFolder.get("entryid");
                recordcount = recordFolder.get('content_count');
            }

            // Notify user
            // # TRANSLATORS: {0} will be replaced by the number of contacts that will be exported
            container.getNotifier().notify('info', dgettext('plugin_contactimporter', 'Contact Export'), String.format(dgettext('plugin_contactimporter', 'Exporting {0} contacts. Please wait...'), recordcount));


            // request attachment preperation
            container.getRequest().singleRequest(
                'contactmodule',
                'export',
                exportPayload,
                responseHandler
            );
        }
    },

    /**
     * Callback for the export request.
     * @param {Object} response
     */
    downloadVCF: function (response) {
        if (response.status == false) {
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_contactimporter', 'Warning'),
                msg: response.message,
                icon: Zarafa.common.dialogs.MessageBox.WARNING,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        } else {
            var downloadFrame = Ext.getBody().createChild({
                tag: 'iframe',
                cls: 'x-hidden'
            });

            var url = document.URL;
            var link = url.substring(0, url.lastIndexOf('/') + 1);

            link += "index.php?sessionid=" + container.getUser().getSessionId() + "&load=custom&name=download_vcf";
            link = Ext.urlAppend(link, "token=" + encodeURIComponent(response.download_token));
            link = Ext.urlAppend(link, "filename=" + encodeURIComponent(response.filename));

            downloadFrame.dom.contentWindow.location = link;
        }
    },

    /**
     * Get all contact folders.
     * @param {boolean} asDropdownStore If true, a simple array store will be returned.
     * @returns {*}
     */
    getAllContactFolders: function (asDropdownStore) {
        asDropdownStore = Ext.isEmpty(asDropdownStore) ? false : asDropdownStore;

        var allFolders = [];

        var defaultContactFolder = container.getHierarchyStore().getDefaultFolder('contact');

        var inbox = container.getHierarchyStore().getDefaultStore();
        var pub = container.getHierarchyStore().getPublicStore();

        if (!Ext.isEmpty(inbox.subStores) && inbox.subStores.folders.totalLength > 0) {
            for (var i = 0; i < inbox.subStores.folders.totalLength; i++) {
                var folder = inbox.subStores.folders.getAt(i);
                if (!Ext.isEmpty(folder) && folder.get("container_class") == "IPF.Contact") {
                    if (asDropdownStore) {
                        allFolders.push([
                            folder.get("entryid"),
                            folder.get("display_name")
                        ]);
                    } else {
                        allFolders.push({
                            display_name: folder.get("display_name"),
                            entryid: folder.get("entryid"),
                            store_entryid: folder.get("store_entryid"),
                            is_public: false
                        });
                    }
                }
            }
        }

        if (!Ext.isEmpty(pub.subStores) && pub.subStores.folders.totalLength > 0) {
            for (var j = 0; j < pub.subStores.folders.totalLength; j++) {
                var folder = pub.subStores.folders.getAt(j);
                if (!Ext.isEmpty(folder) && folder.get("container_class") == "IPF.Contact") {
                    if (asDropdownStore) {
                        allFolders.push([
                            folder.get("entryid"),
                            folder.get("display_name") + " (Public)"
                        ]);
                    } else {
                        allFolders.push({
                            display_name: folder.get("display_name"),
                            entryid: folder.get("entryid"),
                            store_entryid: folder.get("store_entryid"),
                            is_public: true
                        });
                    }
                }
            }
        }

        if (asDropdownStore) {
            return allFolders.sort(Zarafa.plugins.contactimporter.data.Actions.dynamicSort(1));
        } else {
            return allFolders;
        }
    },

    /**
     * Dynamic sort function, sorts by property name.
     * @param {string|int} property
     * @returns {Function}
     */
    dynamicSort: function (property) {
        var sortOrder = 1;
        if (property[0] === "-") {
            sortOrder = -1;
            property = property.substr(1);
        }
        return function (a, b) {
            var result = (a[property].toLowerCase() < b[property].toLowerCase()) ? -1 : (a[property].toLowerCase() > b[property].toLowerCase()) ? 1 : 0;
            return result * sortOrder;
        }
    },

    /**
     * Return a contact folder element by name.
     * @param {string} name
     * @returns {*}
     */
    getContactFolderByName: function (name) {
        var folders = Zarafa.plugins.contactimporter.data.Actions.getAllContactFolders(false);

        for (var i = 0; i < folders.length; i++) {
            if (folders[i].display_name == name) {
                return folders[i];
            }
        }

        return container.getHierarchyStore().getDefaultFolder('contact');
    },

    /**
     * Return a contact folder element by entryid.
     * @param {string} entryid
     * @returns {*}
     */
    getContactFolderByEntryid: function (entryid) {
        var folders = Zarafa.plugins.contactimporter.data.Actions.getAllContactFolders(false);

        for (var i = 0; i < folders.length; i++) {
            if (folders[i].entryid == entryid) {
                return folders[i];
            }
        }

        return container.getHierarchyStore().getDefaultFolder('contact');
    }
};
/**
 * ResponseHandler.js, Kopano Webapp contact to vcf im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/**
 * ResponseHandler
 *
 * This class handles all responses from the php backend
 */
Ext.namespace('Zarafa.plugins.contactimporter.data');

/**
 * @class Zarafa.plugins.contactimporter.data.ResponseHandler
 * @extends Zarafa.plugins.contactimporter.data.AbstractResponseHandler
 *
 * Calendar specific response handler.
 */
Zarafa.plugins.contactimporter.data.ResponseHandler = Ext.extend(Zarafa.core.data.AbstractResponseHandler, {
    /**
     * @cfg {Function} successCallback The function which
     * will be called after success request.
     */
    successCallback: null,

    /**
     * Call the successCallback callback function.
     * @param {Object} response Object contained the response data.
     */
    doLoad: function (response) {
        this.successCallback(response);
    },

    /**
     * Call the successCallback callback function.
     * @param {Object} response Object contained the response data.
     */
    doImport: function (response) {
        this.successCallback(response);
    },

    /**
     * Call the successCallback callback function.
     * @param {Object} response Object contained the response data.
     */
    doExport: function (response) {
        this.successCallback(response);
    },

    /**
     * Call the successCallback callback function.
     * @param {Object} response Object contained the response data.
     */
    doImportattachment: function (response) {
        this.successCallback(response);
    },

    /**
     * In case exception happened on server, server will return
     * exception response with the code of exception.
     * @param {Object} response Object contained the response data.
     */
    doError: function (response) {
        alert("error response code: " + response.error.info.code);
    }
});

Ext.reg('contactimporter.contactresponsehandler', Zarafa.plugins.contactimporter.data.ResponseHandler);/**
 * ImportContentPanel.js, Kopano Webapp contact to vcf im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/**
 * ImportContentPanel
 *
 * Container for the importpanel.
 */
Ext.namespace("Zarafa.plugins.contactimporter.dialogs");

/**
 * @class Zarafa.plugins.contactimporter.dialogs.ImportContentPanel
 * @extends Zarafa.core.ui.ContentPanel
 *
 * The content panel which shows the hierarchy tree of Owncloud account files.
 * @xtype contactimportercontentpanel
 */
Zarafa.plugins.contactimporter.dialogs.ImportContentPanel = Ext.extend(Zarafa.core.ui.ContentPanel, {

    /**
     * @constructor
     * @param config Configuration structure
     */
    constructor: function (config) {
        config = config || {};
        var title = dgettext('plugin_contactimporter', 'Import Contacts');
        Ext.applyIf(config, {
            layout: 'fit',
            title: title,
            closeOnSave: true,
            width: 620,
            height: 465,
            //Add panel
            items: [
                {
                    xtype: 'contactimporter.importcontactpanel',
                    filename: config.filename,
                    folder: config.folder
                }
            ]
        });

        Zarafa.plugins.contactimporter.dialogs.ImportContentPanel.superclass.constructor.call(this, config);
    }

});

Ext.reg('contactimporter.contentpanel', Zarafa.plugins.contactimporter.dialogs.ImportContentPanel);/**
 * ImportPanel.js, Kopano Webapp contact to vcf im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/**
 * ImportPanel
 *
 * The main Panel of the contactimporter plugin.
 */
Ext.namespace("Zarafa.plugins.contactimporter.dialogs");

/**
 * @class Zarafa.plugins.contactimporter.dialogs.ImportPanel
 * @extends Ext.Panel
 */
Zarafa.plugins.contactimporter.dialogs.ImportPanel = Ext.extend(Ext.Panel, {

    /* path to vcf file on server... */
    vcffile: null,

    /* The store for the selection grid */
    store: null,

    /* selected folder */
    folder: null,

    /**
     * @constructor
     * @param {object} config
     */
    constructor: function (config) {
        config = config || {};
        var self = this;

        if (!Ext.isEmpty(config.filename)) {
            this.vcffile = config.filename;
        }

        if (!Ext.isEmpty(config.folder)) {
            this.folder = config.folder;
        }

        // create the data store
        // we only display the firstname, lastname, homephone and primary email address in our grid
        this.store = new Ext.data.ArrayStore({
            fields: [
                {name: 'display_name'},
                {name: 'given_name'},
                {name: 'surname'},
                {name: 'company_name'},
                {name: 'record'}
            ]
        });

        Ext.apply(config, {
            xtype: 'contactimporter.importpanel',
            ref: "importcontactpanel",
            layout: {
                type: 'form',
                align: 'stretch'
            },
            anchor: '100%',
            bodyStyle: 'background-color: inherit;',
            defaults: {
                border: true,
                bodyStyle: 'background-color: inherit; padding: 3px 0px 3px 0px; border-style: none none solid none;'
            },
            items: [
                this.createSelectBox(),
                this.initForm(),
                this.createGrid()
            ],
            buttons: [
                this.createSubmitAllButton(),
                this.createSubmitButton(),
                this.createCancelButton()
            ],
            listeners: {
                afterrender: function (cmp) {
                    this.loadMask = new Ext.LoadMask(this.getEl(), {msg: dgettext('plugin_contactimporter', 'Loading...')});

                    if (this.vcffile != null) { // if we have got the filename from an attachment
                        this.parseContacts(this.vcffile);
                    }
                },
                scope: this
            }
        });

        Zarafa.plugins.contactimporter.dialogs.ImportPanel.superclass.constructor.call(this, config);
    },

    /**
     * Init embedded form, this is the form that is
     * posted and contains the attachments
     * @private
     */
    initForm: function () {
        return {
            xtype: 'form',
            ref: 'addContactFormPanel',
            layout: 'column',
            fileUpload: true,
            autoWidth: true,
            autoHeight: true,
            border: false,
            bodyStyle: 'padding: 5px;',
            defaults: {
                anchor: '95%',
                border: false,
                bodyStyle: 'padding: 5px;'
            },
            items: [this.createUploadField()]
        };
    },

    /**
     * Reloads the data of the grid
     * @private
     */
    reloadGridStore: function (contactdata) {
        var parsedData = [];

        if (contactdata) {
            parsedData = new Array(contactdata.contacts.length);
            var i = 0;
            for (i = 0; i < contactdata.contacts.length; i++) {

                parsedData[i] = [
                    contactdata.contacts[i]["display_name"],
                    contactdata.contacts[i]["given_name"],
                    contactdata.contacts[i]["surname"],
                    contactdata.contacts[i]["company_name"],
                    contactdata.contacts[i]
                ];
            }
        } else {
            return null;
        }

        this.store.loadData(parsedData, false);
    },

    /**
     * Init embedded form, this is the form that is
     * posted and contains the attachments
     * @private
     */
    createGrid: function () {
        return {
            xtype: 'grid',
            ref: 'contactGrid',
            columnWidth: 1.0,
            store: this.store,
            width: '100%',
            height: 300,
            title: dgettext('plugin_contactimporter', 'Select contacts to import'),
            frame: false,
            viewConfig: {
                forceFit: true
            },
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    width: 300,
                    sortable: true
                },
                columns: [
                    {id: 'Displayname', header: dgettext('plugin_contactimporter', 'Displayname'), width: 350, sortable: true, dataIndex: 'display_name'},
                    {header: dgettext('plugin_contactimporter', 'Firstname'), width: 200, sortable: true, dataIndex: 'given_name'},
                    {header: dgettext('plugin_contactimporter', 'Lastname'), width: 200, sortable: true, dataIndex: 'surname'},
                    {header: dgettext('plugin_contactimporter', 'Company'), sortable: true, dataIndex: 'company_name'}
                ]
            }),
            sm: new Ext.grid.RowSelectionModel({multiSelect: true})
        }
    },

    /**
     * Generate the UI addressbook select box.
     * @returns {*}
     */
    createSelectBox: function () {
        var myStore = Zarafa.plugins.contactimporter.data.Actions.getAllContactFolders(true);

        return {
            xtype: "selectbox",
            ref: 'addressbookSelector',
            editable: false,
            name: "choosen_addressbook",
            value: Ext.isEmpty(this.folder) ? Zarafa.plugins.contactimporter.data.Actions.getContactFolderByName(container.getSettingsModel().get("zarafa/v1/plugins/contactimporter/default_addressbook")).entryid : this.folder,
            width: 100,
            fieldLabel: dgettext('plugin_contactimporter', 'Select folder'),
            store: myStore,
            mode: 'local',
            labelSeperator: ":",
            border: false,
            anchor: "100%",
            scope: this,
            hidden: Ext.isEmpty(this.folder) ? false : true,
            allowBlank: false
        }
    },

    /**
     * Generate the UI upload field.
     * @returns {*}
     */
    createUploadField: function () {
        return {
            xtype: "fileuploadfield",
            ref: 'contactfileuploadfield',
            columnWidth: 1.0,
            id: 'form-file',
            name: 'vcfdata',
            emptyText: dgettext('plugin_contactimporter', 'Select an .vcf addressbook'),
            border: false,
            anchor: "100%",
            height: "30",
            scope: this,
            allowBlank: false,
            listeners: {
                'fileselected': this.onFileSelected,
                scope: this
            }
        }
    },

    /**
     * Generate the UI submit button.
     * @returns {*}
     */
    createSubmitButton: function () {
        return {
            xtype: "button",
            ref: "../submitButton",
            disabled: true,
            width: 100,
            border: false,
            text: dgettext('plugin_contactimporter', 'Import'),
            anchor: "100%",
            handler: this.importCheckedContacts,
            scope: this,
            allowBlank: false
        }
    },

    /**
     * Generate the UI submit all button.
     * @returns {*}
     */
    createSubmitAllButton: function () {
        return {
            xtype: "button",
            ref: "../submitAllButton",
            disabled: true,
            width: 100,
            border: false,
            text: dgettext('plugin_contactimporter', 'Import All'),
            anchor: "100%",
            handler: this.importAllContacts,
            scope: this,
            allowBlank: false
        }
    },

    /**
     * Generate the UI cancel button.
     * @returns {*}
     */
    createCancelButton: function () {
        return {
            xtype: "button",
            width: 100,
            border: false,
            text: dgettext('plugin_contactimporter', 'Cancel'),
            anchor: "100%",
            handler: this.close,
            scope: this,
            allowBlank: false
        }
    },

    /**
     * This is called when a file has been seleceted in the file dialog
     * in the {@link Ext.ux.form.FileUploadField} and the dialog is closed
     * @param {Ext.ux.form.FileUploadField} uploadField being added a file to
     */
    onFileSelected: function (uploadField) {
        var form = this.addContactFormPanel.getForm();

        if (form.isValid()) {
            form.submit({
                waitMsg: dgettext('plugin_contactimporter', 'Uploading and parsing contacts...'),
                url: 'plugins/contactimporter/php/upload.php',
                failure: function (file, action) {
                    this.submitButton.disable();
                    this.submitAllButton.disable();
                    Zarafa.common.dialogs.MessageBox.show({
                        title: dgettext('plugin_contactimporter', 'Error'),
                        msg: action.result.error,
                        icon: Zarafa.common.dialogs.MessageBox.ERROR,
                        buttons: Zarafa.common.dialogs.MessageBox.OK
                    });
                },
                success: function (file, action) {
                    uploadField.reset();
                    this.vcffile = action.result.vcf_file;

                    this.parseContacts(this.vcffile);
                },
                scope: this
            });
        }
    },

    /**
     * Start request to server to parse the given vCard file.
     * @param {string} vcfPath
     */
    parseContacts: function (vcfPath) {
        this.loadMask.show();

        // call export function here!
        var responseHandler = new Zarafa.plugins.contactimporter.data.ResponseHandler({
            successCallback: this.handleParsingResult.createDelegate(this)
        });

        container.getRequest().singleRequest(
            'contactmodule',
            'load',
            {
                vcf_filepath: vcfPath
            },
            responseHandler
        );
    },

    /**
     * Callback for the parsing request.
     * @param {Object} response
     */
    handleParsingResult: function (response) {
        this.loadMask.hide();

        if (response["status"] == true) {
            this.submitButton.enable();
            this.submitAllButton.enable();

            this.reloadGridStore(response.parsed);
        } else {
            this.submitButton.disable();
            this.submitAllButton.disable();
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_contactimporter', 'Parser Error'),
                msg: _(response["message"]),
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        }
    },

    /**
     * Close the UI dialog.
     */
    close: function () {
        this.addContactFormPanel.getForm().reset();
        this.dialog.close()
    },

    /**
     * Create a request to import all selected contacts.
     */
    importCheckedContacts: function () {
        var newRecords = this.contactGrid.selModel.getSelections();
        this.importContacts(newRecords);
    },

    /**
     * Check all contacts and import them.
     */
    importAllContacts: function () {
        //receive Records from grid rows
        this.contactGrid.selModel.selectAll();  // select all entries
        var newRecords = this.contactGrid.selModel.getSelections();
        this.importContacts(newRecords);
    },

    /**
     * This function stores all given events to the contact store
     * @param {array} contacts
     */
    importContacts: function (contacts) {
        //receive existing contact store
        var folderValue = this.addressbookSelector.getValue();

        if (folderValue == undefined) { // no addressbook choosen
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_contactimporter', 'Error'),
                msg: dgettext('plugin_contactimporter', 'You have to choose an addressbook!'),
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        } else {
            if (this.contactGrid.selModel.getCount() < 1) {
                Zarafa.common.dialogs.MessageBox.show({
                    title: dgettext('plugin_contactimporter', 'Error'),
                    msg: dgettext('plugin_contactimporter', 'You have to choose at least one contact to import!'),
                    icon: Zarafa.common.dialogs.MessageBox.ERROR,
                    buttons: Zarafa.common.dialogs.MessageBox.OK
                });
            } else {
                var contactFolder = Zarafa.plugins.contactimporter.data.Actions.getContactFolderByEntryid(folderValue);

                this.loadMask.show();
                var uids = [];

                //receive Records from grid rows
                Ext.each(contacts, function (newRecord) {
                    uids.push(newRecord.data.record.internal_fields.contact_uid);
                }, this);

                var responseHandler = new Zarafa.plugins.contactimporter.data.ResponseHandler({
                    successCallback: this.importContactsDone.createDelegate(this)
                });

                container.getRequest().singleRequest(
                    'contactmodule',
                    'import',
                    {
                        storeid: contactFolder.store_entryid,
                        folderid: contactFolder.entryid,
                        uids: uids,
                        vcf_filepath: this.vcffile
                    },
                    responseHandler
                );
            }
        }
    },

    /**
     * Callback for the import request.
     * @param {Object} response
     */
    importContactsDone: function (response) {
        this.loadMask.hide();
        this.dialog.close();
        if (response.status == true) {
            // # TRANSLATORS: {0} will be replaced by the number of contacts that were imported
            container.getNotifier().notify('info', dgettext('plugin_contactimporter', 'Imported'), String.format(dgettext('plugin_contactimporter', 'Imported {0} contacts. Please reload your addressbook!'), response.count));
        } else {
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_contactimporter', 'Error'),
                // # TRANSLATORS: {0} will be replaced by the error message
                msg: String.format(dgettext('plugin_contactimporter', 'Import failed: {0}'), response.message),
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        }
    }
});

Ext.reg('contactimporter.importcontactpanel', Zarafa.plugins.contactimporter.dialogs.ImportPanel);
/**
 * plugin.contactimporter.js, Kopano Webapp contact to vcf im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace("Zarafa.plugins.contactimporter");									// Assign the right namespace

Zarafa.plugins.contactimporter.ImportPlugin = Ext.extend(Zarafa.core.Plugin, {		// create new import plugin

    /**
     * @constructor
     * @param {Object} config Configuration object
     *
     */
    constructor: function (config) {
        config = config || {};

        Zarafa.plugins.contactimporter.ImportPlugin.superclass.constructor.call(this, config);
    },

    /**
     * initialises insertion point for plugin
     * @protected
     */
    initPlugin: function () {
        Zarafa.plugins.contactimporter.ImportPlugin.superclass.initPlugin.apply(this, arguments);

        /* our panel */
        Zarafa.core.data.SharedComponentType.addProperty('plugins.contactimporter.dialogs.importcontacts');

        /* directly import received vcfs */
        this.registerInsertionPoint('common.contextmenu.attachment.actions', this.createAttachmentImportButton, this);

        /* export a contact via rightclick */
        this.registerInsertionPoint('context.contact.contextmenu.actions', this.createItemExportInsertionPoint, this);
    },

    /**
     * This method hooks to the contact context menu and allows users to export users to vcf.
     *
     * @param include
     * @param btn
     * @returns {Object}
     */
    createItemExportInsertionPoint: function (include, btn) {
        return {
            text: dgettext('plugin_contactimporter', 'Export vCard'),
            handler: this.exportToVCF.createDelegate(this, [btn]),
            scope: this,
            iconCls: 'icon_contactimporter_export'
        };
    },

    /**
     * Generates a request to download the selected records as vCard.
     * @param {Ext.Button} btn
     */
    exportToVCF: function (btn) {
        if (btn.records.length == 0) {
            return; // skip if no records where given!
        }

        var recordIds = [];

        for (var i = 0; i < btn.records.length; i++) {
            recordIds.push(btn.records[i].get("entryid"));
        }

        Zarafa.plugins.contactimporter.data.Actions.exportToVCF(btn.records[0].get("store_entryid"), recordIds, undefined);
    },

    /**
     * Insert import button in all attachment suggestions

     * @return {Object} Configuration object for a {@link Ext.Button button}
     */
    createAttachmentImportButton: function (include, btn) {
        return {
            text: dgettext('plugin_contactimporter', 'Import to Contacts'),
            handler: this.getAttachmentFileName.createDelegate(this, [btn]),
            scope: this,
            iconCls: 'icon_contactimporter_button',
            beforeShow: function (item, record) {
                var extension = record.data.name.split('.').pop().toLowerCase();

                if (record.data.filetype == "text/vcard" || record.data.filetype == "text/x-vcard" || extension == "vcf" || extension == "vcard") {
                    item.setVisible(true);
                } else {
                    item.setVisible(false);
                }
            }
        };
    },

    /**
     * Callback for getAttachmentFileName
     * @param {Object} response
     */
    gotAttachmentFileName: function (response) {
        if (response.status == true) {
            this.openImportDialog(response.tmpname);
        } else {
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_contactimporter', 'Error'),
                msg: _(response["message"]),
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        }
    },

    /**
     * Clickhandler for the button
     * @param {Ext.Button} btn
     */
    getAttachmentFileName: function (btn) {
        Zarafa.common.dialogs.MessageBox.show({
            title: dgettext('plugin_contactimporter', 'Please wait'),
            msg: dgettext('plugin_contactimporter', 'Loading attachment...'),
            progressText: dgettext('plugin_contactimporter', 'Initializing...'),
            width: 300,
            progress: true,
            closable: false
        });

        // progress bar... ;)
        var f = function (v) {
            return function () {
                if (v == 100) {
                    Zarafa.common.dialogs.MessageBox.hide();
                } else {
                    // # TRANSLATORS: {0} will be replaced by the percentage value (0-100)
                    Zarafa.common.dialogs.MessageBox.updateProgress(v / 100, String.format(dgettext('plugin_contactimporter', '{0}% loaded'), Math.round(v)));
                }
            };
        };

        for (var i = 1; i < 101; i++) {
            setTimeout(f(i), 20 * i);
        }

        /* store the attachment to a temporary folder and prepare it for uploading */
        var attachmentRecord = btn.records;
        var attachmentStore = attachmentRecord.store;

        var store = attachmentStore.getParentRecord().get('store_entryid');
        var entryid = attachmentStore.getAttachmentParentRecordEntryId();
        var attachNum = new Array(1);
        if (attachmentRecord.get('attach_num') != -1) {
            attachNum[0] = attachmentRecord.get('attach_num');
        } else {
            attachNum[0] = attachmentRecord.get('tmpname');
        }
        var dialog_attachments = attachmentStore.getId();
        var filename = attachmentRecord.data.name;

        var responseHandler = new Zarafa.plugins.contactimporter.data.ResponseHandler({
            successCallback: this.gotAttachmentFileName.createDelegate(this),
            scope: this
        });

        // request attachment preperation
        container.getRequest().singleRequest(
            'contactmodule',
            'importattachment',
            {
                entryid: entryid,
                store: store,
                attachNum: attachNum,
                dialog_attachments: dialog_attachments,
                filename: filename
            },
            responseHandler
        );
    },

    /**
     * Open the import dialog.
     * @param {String} filename
     */
    openImportDialog: function (filename) {
        var componentType = Zarafa.core.data.SharedComponentType['plugins.contactimporter.dialogs.importcontacts'];
        var config = {
            filename: filename,
            modal: true
        };

        Zarafa.core.data.UIFactory.openLayerComponent(componentType, undefined, config);
    },

    /**
     * Bid for the type of shared component
     * and the given record.
     * This will bid on calendar.dialogs.importcontacts
     * @param {Zarafa.core.data.SharedComponentType} type Type of component a context can bid for.
     * @param {Ext.data.Record} record Optionally passed record.
     * @return {Number} The bid for the shared component
     */
    bidSharedComponent: function (type, record) {
        var bid = -1;
        switch (type) {
            case Zarafa.core.data.SharedComponentType['plugins.contactimporter.dialogs.importcontacts']:
                bid = 1;
                break;
            case Zarafa.core.data.SharedComponentType['common.contextmenu']:
                if (record instanceof Zarafa.core.data.MAPIRecord) {
                    if (record.get('object_type') == Zarafa.core.mapi.ObjectType.MAPI_FOLDER && record.get('container_class') == "IPF.Contact") {
                        bid = 2;
                    }
                }
                break;
        }
        return bid;
    },

    /**
     * Will return the reference to the shared component.
     * Based on the type of component requested a component is returned.
     * @param {Zarafa.core.data.SharedComponentType} type Type of component a context can bid for.
     * @param {Ext.data.Record} record Optionally passed record.
     * @return {Ext.Component} Component
     */
    getSharedComponent: function (type, record) {
        var component;
        switch (type) {
            case Zarafa.core.data.SharedComponentType['plugins.contactimporter.dialogs.importcontacts']:
                component = Zarafa.plugins.contactimporter.dialogs.ImportContentPanel;
                break;
            case Zarafa.core.data.SharedComponentType['common.contextmenu']:
                component = Zarafa.plugins.contactimporter.ui.ContextMenu;
                break;
        }

        return component;
    }
});


/*############################################################################################################################
 * STARTUP 
 *############################################################################################################################*/
Zarafa.onReady(function () {
    container.registerPlugin(new Zarafa.core.PluginMetaData({
        name: 'contactimporter',
        displayName: dgettext('plugin_contactimporter', 'Contactimporter Plugin'),
        about: Zarafa.plugins.contactimporter.ABOUT,
        pluginConstructor: Zarafa.plugins.contactimporter.ImportPlugin
    }));
});
/**
 * ContextMenu.js, Kopano Webapp contact to vcf im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.contactimporter.ui');

/**
 * @class Zarafa.plugins.contactimporter.ui.ContextMenu
 * @extends Zarafa.hierarchy.ui.ContextMenu
 * @xtype contactimporter.hierarchycontextmenu
 */
Zarafa.plugins.contactimporter.ui.ContextMenu = Ext.extend(Zarafa.hierarchy.ui.ContextMenu, {

    /**
     * @constructor
     * @param {Object} config Configuration object
     */
    constructor: function (config) {
        config = config || {};

        if (config.contextNode) {
            config.contextTree = config.contextNode.getOwnerTree();
        }

        Zarafa.plugins.contactimporter.ui.ContextMenu.superclass.constructor.call(this, config);

        // add item to menu
        var additionalItems = this.createAdditionalContextMenuItems(config);
        for (var i = 0; i < additionalItems.length; i++) {
            config.items[0].push(additionalItems[i]);
        }

        Zarafa.plugins.contactimporter.ui.ContextMenu.superclass.constructor.call(this, config); // redo ... otherwise menu does not get published
    },

    /**
     * Create the Action context menu items.
     * @param {Object} config Configuration object for the {@link Zarafa.plugins.contactimporter.ui.ContextMenu ContextMenu}
     * @return {Zarafa.core.ui.menu.ConditionalItem|Array} The list of Action context menu items
     * @private
     *
     * Note: All handlers are called within the scope of {@link Zarafa.plugins.contactimporter.ui.ContextMenu HierarchyContextMenu}
     */
    createAdditionalContextMenuItems: function (config) {
        return [{
            xtype: 'menuseparator'
        }, {
            text: dgettext('plugin_contactimporter', 'Import vCard'),
            iconCls: 'icon_contactimporter_import',
            handler: this.onContextItemImport,
            beforeShow: function (item, record) {
                var access = record.get('access') & Zarafa.core.mapi.Access.ACCESS_MODIFY;
                if (!access || (record.isIPMSubTree() && !record.getMAPIStore().isDefaultStore())) {
                    item.setDisabled(true);
                } else {
                    item.setDisabled(false);
                }
            }
        }, {
            text: dgettext('plugin_contactimporter', 'Export vCard'),
            iconCls: 'icon_contactimporter_export',
            handler: this.onContextItemExport,
            beforeShow: function (item, record) {
                var access = record.get('access') & Zarafa.core.mapi.Access.ACCESS_READ;
                if (!access || (record.isIPMSubTree() && !record.getMAPIStore().isDefaultStore())) {
                    item.setDisabled(true);
                } else {
                    item.setDisabled(false);
                }
            }
        }];
    },

    /**
     * Fires on selecting 'Open' menu option from {@link Zarafa.plugins.contactimporter.ui.ContextMenu ContextMenu}
     * @private
     */
    onContextItemExport: function () {
        Zarafa.plugins.contactimporter.data.Actions.exportToVCF(this.records.get("store_entryid"), undefined, this.records);
    },

    /**
     * Fires on selecting 'Open' menu option from {@link Zarafa.plugins.contactimporter.ui.ContextMenu ContextMenu}
     * @private
     */
    onContextItemImport: function () {
        var componentType = Zarafa.core.data.SharedComponentType['plugins.contactimporter.dialogs.importcontacts'];
        var config = {
            modal: true,
            folder: this.records.get("entryid")
        };

        Zarafa.core.data.UIFactory.openLayerComponent(componentType, undefined, config);
    }
});

Ext.reg('contactimporter.hierarchycontextmenu', Zarafa.plugins.contactimporter.ui.ContextMenu);
